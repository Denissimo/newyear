Philosophy
==========

Paris is built with the same *less is more* philosophy as `Idiorm`_.

.. _Idiorm: http://github.com/j4mie/idiorm/