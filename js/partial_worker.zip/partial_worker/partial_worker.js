/*
 * Copyright© 2012 Ascatel Inc.. All rights reserved.
 *
 * It is a part of Asymbix project.
 * Licensed under the Asymbix project License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.asymbix/licenses/LICENSE-1.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the full volume of permissions and
 * limitations under the License.
 */

/**
 * @class dropdownMenu
 * <this file contains javascript code for AJAX requests>
 * @author Maxim Korzh <a href="mailto:korj@ascatel.com">&lt; korj@ascatel.com&gt;</a>
 * @version 2013-08-20 17:00:00
 */
 
/**
 * Библиотека предназназначена для HTML5 Web Worker и выполняет подключение шаблонов и подстановку в них JavaScript переменных.
 * для работы скрипт требует дополнительные js скрипты, которые должны находится в том же месте, что и partial_worker.js:
 *   - ajax.js - библиотека, реализующая AJAX запрос
 *   - partial.js - JavaScritp код для основной страницы
 *
 * поскольку данные, передаваемые в worker клонируются, то, что бы избежать расходов ресурсов worker получает шаблон в виде строки и, после обрабоки, 
 * возвращает в основной документ тело новой функции, выполняющей подстановку данных. 
 */

var cache = {};

var prepare = function(string){
  return string.replace(/[\r\t\n]/g, " ").split(/<%\s*/).join("\t").replace(/((^|%>)[^\t]*)'/g, "$1\r");
}

var RECURSION_ERROR = function(partialName){return '[ '+partialName+' too much recursion ]';}

var loadIncludedPartials = function(loader, partialAsString, parentPartial){
  var includes = null;
  var index = 0;
  var temp = '';
  
  includes = prepare(partialAsString).match(/\t@\s*.*?\s*%>/g);
  if (includes){
    if (parentPartial && !(parentPartial instanceof Array)) parentPartial = [parentPartial];
  
    index = includes.length;
    loader.includes += index;
    while (index--){
      temp = includes[index].replace(/(?:\t@|\s+|%>)/g, '');
      if (cache[temp]){
        if (parentPartial.indexOf(temp) == -1) loadIncludedPartials(loader, cache[temp], (parentPartial ? [temp].concat(parentPartial) : [temp]));
        else cache[parentPartial[0]] = RECURSION_ERROR(parentPartial[0]);

        loader.includes--;
        if (loader.includes < 1) loader.resolve();
      }
      else{
        (function(key, parent){
          Ajax.request({
            method: 'get',
            url: key,
            timeout: 100,
            success: function(partial){
              cache[key] = partial;
              loadIncludedPartials(loader, partial, (parent ? [key].concat(parent) : [key]));
              
              loader.includes--;
              if (loader.includes < 1) loader.resolve();
            },
            error: function(jqXHR, textStatus, errorThrown){
              cache[key] = key+': '+(errorThrown || textStatus);
              
              loader.includes--;
              if (loader.includes < 1) loader.resolve();
            }
          });
        })(temp, parentPartial);
      }
    }
  }

  includes = null;
  index = null;
  temp = null;
}


onmessage = function(event){
  var params = event.data;

  var temp = {
    includes: 0,
    current: '',
    resolve: function(){
      postMessage("var p=[];try{with(obj){p.push('" +
        prepare(this.current)
        .replace(/\t@\s*(.*?)\s*%>/g, function include(dummy, patternName){
          return prepare(cache[patternName]).replace(/\t@\s*(.*?)\s*%>/g, include);
        })
        .replace(/\t=\s*(.*?)%>/g, "',$1,'")
        .split("\t").join("');")
        .split("%>").join("p.push('")
        .split("\r").join("\\'") + "');}}catch(e){p=[e]};return p.join('');");
    }
  };
  
  importScripts(params.scriptPath+'ajax.js');

  Ajax.request({
    url: params.partial,
    method: 'get',
    timeout: 100,
    success: function(data){
      temp.current = data;
      loadIncludedPartials(temp, data, params.partial);
    },
    error: function(data){
      postMessage(data)
    }
  });
  
};