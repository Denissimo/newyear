/*
 * Copyright© 2012 Ascatel Inc.. All rights reserved.
 *
 * It is a part of Asymbix project.
 * Licensed under the Asymbix project License, Version 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.asymbix/licenses/LICENSE-1.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the full volume of permissions and
 * limitations under the License.
 */

/**
 * @class dropdownMenu
 * <this file contains javascript code for AJAX requests>
 * @author Maxim Korzh <a href="mailto:korj@ascatel.com">&lt; korj@ascatel.com&gt;</a>
 * @version 2013-08-20 17:00:00
 */
 
/**
 * Скрипт предназначен для обработки шаблонов на основной странице ( не в worker ).
 * Для работоспособности требуется jQuery c поддержкой Defrred объектов.
 * 
 * Использование:
 *   Partial(PARTIAL_PATH).render(JSON, CALLBACK),
 *   где:
 *     PARTIAL_PATH - путь к загружаемому через AJAX шаблону
 *     JSON - набор подставляемых данных для шаблона ( включая подшаблоны )
 *     CALLBACK - функция, вызываемая после получения от Web Worker данных 
 *
 * оформление шаблонов.
 * для построение логических и пр. конструкция в шаблоне используется JavaScript, обрамлённый "<%" и "%>". несколько строк, желательно не объеденять в один блок, поскольку при наличии непонятных для JS символов или слов, 
 * будет сгенерирована ошибка.
 *
 * Пример:
 *   --- шаблон full.tpl ---
 *   <h1><%= data.caption %></h1>
 *   <p><%@ info.tpl %></p>
 *   <ul>
 *     <% for ( var i = 0; i < data.users.length; i++ ) { %>
 *       <%@ item.tpl %>
 *     <% } %>
 *   </ul>
 *
 *   --- шаблон item.tpl ---
 *   <li><a href="<%=data.users[i].url%>"><%=data.users[i].name%></a></li>
 *
 *
 *
 *   <%@ ... %> - подключение подшаблона
 *   <%= ... %> - вывод переменной
 *
 *   --- Набор данных ---
 *     var dataSet = {
 *       data: {
 *         caption : 'data caption',
 *         users   : [
 *           { url : '/#user1', name: 'USER #1' },
 *           { url : '/#user2', name: 'USER #2' },
 *           { url : '/#user3', name: 'USER #3' },
 *           { url : '/#user4', name: 'USER #4' },
 *           { url : '/#user5', name: 'USER #5' },
 *           { url : '/#user6', name: 'USER #6' },
 *           { url : '/#user7', name: 'USER #7' }
 *         ]
 *       }
 *     }
 *
 *   --- Вызов --- 
 *
 *   window.Asymbix.Partial('full.tpl').render(dataSet, function(result){
 *     document.getElementById('container1').innerHTML = result;
 *   });
 */
 
if (!window.Asymbix) window.Asymbix = {};
window.Asymbix.Partial = function(partialPath){
  var scriptPath = (function(){// функция определяет путь к текущему скрипту для подключения всех нобоходимых файлов.
    var url = '';
    var scripts = document.getElementsByTagName('script');
    var index = scripts.length;
    var temp = null;
    while (index--){
      temp = scripts[index].src.match(/(.*\W)partial.js$/);
      if (temp){
        url = temp.pop();
        break;
      }
    }
    scripts = null;
    index = null;
    temp = null;
    return url;
  })();
  
  var deferred = null;
  
  this.render = function(data, callback){
    deferred = $.Deferred(function(){
      var worker = new Worker(scriptPath+'partial_worker.js');
      
      worker.onmessage = function(event){
        deferred.resolve((new Function('obj', event.data))(data || {}));
      }
  
      worker.onerror = function(event){
        deferred.reject(event.data);
      }
      
      worker.postMessage({
        scriptPath: scriptPath,
        partial: partialPath
      });
    });
    
    deferred.always(callback);
  }
  
  return this;
}